
-- --------------------------------------------------------

--
-- Table structure for table `medical_supplies`
--

CREATE TABLE `medical_supplies` (
  `Item_ID` int(11) NOT NULL,
  `Item_Name` varchar(255) NOT NULL,
  `Item_Price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medical_supplies`
--

INSERT INTO `medical_supplies` (`Item_ID`, `Item_Name`, `Item_Price`) VALUES
(12, 'Isopropyl Alcohol', '12.15'),
(13, 'AA Batteries', '10.20'),
(14, '9V Batteries', '8.79'),
(15, 'Clorox Bleach', '7.13'),
(16, 'Clorox Disinfecting Wipes', '11.97'),
(17, 'Dawn Dish Detergent', '2.67'),
(18, 'Distilled Water', '44.99'),
(19, 'Dryer Sheets', '3.47'),
(20, 'Electric Blankets - Twin Size', '46.95'),
(21, 'Hand Soap Refill', '3.84'),
(22, 'Hand Sanitizer Refill', '5.97'),
(23, 'Karo Syrup', '7.49'),
(24, 'Laundry Detergent', '8.97'),
(25, 'Mop', '8.24'),
(26, 'Mop Head', '5.48'),
(27, 'Spare Newspaper', '0.00'),
(28, 'OxiClean', '4.99'),
(29, 'Hydrogen Peroxide', '1.09'),
(30, 'Paper Towels', '8.99'),
(31, 'Rice - Large Bag', '8.92'),
(32, 'Towels', '6.68'),
(33, '13-Gal. Trashbags', '14.97'),
(34, '39-Gal. Trashbags', '8.97'),
(35, 'Tube Socks', '4.93'),
(36, 'Washcloths', '3.92'),
(37, 'Ziploc Sandwich Bags', '2.98'),
(38, 'Zip Ties', '5.64');
