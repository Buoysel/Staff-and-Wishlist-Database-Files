
-- --------------------------------------------------------

--
-- Table structure for table `transport_supplies`
--

CREATE TABLE `transport_supplies` (
  `Item_ID` int(11) NOT NULL,
  `Item_Name` varchar(255) NOT NULL,
  `Item_Price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transport_supplies`
--

INSERT INTO `transport_supplies` (`Item_ID`, `Item_Name`, `Item_Price`) VALUES
(39, 'Plastic Crates (Any Size)', '9.99'),
(40, 'Fuel Gift Cards', '10.00');
