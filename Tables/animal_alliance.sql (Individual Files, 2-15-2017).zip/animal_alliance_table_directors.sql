
-- --------------------------------------------------------

--
-- Table structure for table `directors`
--

CREATE TABLE `directors` (
  `Director_ID` int(11) NOT NULL,
  `Director_Name` varchar(255) NOT NULL,
  `Director_Title` varchar(255) DEFAULT NULL,
  `Director_Image` varchar(255) DEFAULT NULL,
  `Director_Bio` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `directors`
--

INSERT INTO `directors` (`Director_ID`, `Director_Name`, `Director_Title`, `Director_Image`, `Director_Bio`) VALUES
(1, 'Nancy Williams', NULL, '../FileUploads/AnimalClinic/img/directors/nwilliams.jpg', NULL),
(2, 'John Dobson', NULL, '../FileUploads/AnimalClinic/img/directors/jdobson.jpg', NULL),
(3, 'Sara Lehner', NULL, '../FileUploads/AnimalClinic/img/directors/slehner.jpg', NULL),
(4, 'Kristin Johnson', NULL, '../FileUploads/AnimalClinic/img/directors/kjohnson.jpg', NULL),
(5, 'Jane Dempsey', NULL, '../FileUploads/AnimalClinic/img/directors/jdempsey.jpg', NULL),
(6, 'Karen Martin', NULL, '../FileUploads/AnimalClinic/img/directors/kmartin.jpg', NULL),
(7, 'Allyson McPhaul', NULL, '../FileUploads/AnimalClinic/img/directors/amcphaul.jpg', NULL),
(8, 'Ryan Langley', NULL, '../FileUploads/AnimalClinic/img/directors/rlangley.jpg', NULL);
