
-- --------------------------------------------------------

--
-- Table structure for table `office_supplies`
--

CREATE TABLE `office_supplies` (
  `Item_ID` int(11) NOT NULL,
  `Item_Name` varchar(255) NOT NULL,
  `Item_Price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `office_supplies`
--

INSERT INTO `office_supplies` (`Item_ID`, `Item_Name`, `Item_Price`) VALUES
(4, 'Sharpie Markers', '5.61'),
(5, 'Paper', '14.99'),
(6, 'Hand Sanitizer', '8.68'),
(7, 'Highlighter', '6.49'),
(8, 'Masking Tape', '3.98'),
(9, 'Scotch Tape Refills', '6.35'),
(10, 'Staples', '3.59'),
(11, 'Pens', '4.19');
