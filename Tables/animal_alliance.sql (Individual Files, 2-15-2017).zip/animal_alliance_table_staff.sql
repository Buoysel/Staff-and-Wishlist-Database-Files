
-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_ID` int(11) NOT NULL,
  `Staff_Name` varchar(255) NOT NULL,
  `Staff_Title` varchar(255) DEFAULT NULL,
  `Staff_Image` varchar(255) DEFAULT NULL,
  `Staff_Bio` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_ID`, `Staff_Name`, `Staff_Title`, `Staff_Image`, `Staff_Bio`) VALUES
(1, 'Christina Richards', 'Executive Director', '../FileUploads/AnimalClinic/img/staff/crichards.jpg', NULL),
(2, 'Kristen Hayes Taylor', 'Clinic Supervisor', '../FileUploads/AnimalClinic/img/staff/khtaylor.jpg', NULL),
(3, 'Dr. Michelle Redfern, DVM', 'Chief Veterinarian', '../FileUploads/AnimalClinic/img/staff/mredfern.jpg', NULL),
(4, 'Dr. Donovan Qualls, DVM', 'Associate Veterinarian', '../FileUploads/AnimalClinic/img/staff/dqualls.jpg', NULL),
(5, 'Heather Knight', 'Vet. Tech./Data Entry', '../FileUploads/AnimalClinic/img/staff/hknight.jpg', NULL),
(6, 'Monica Koch', 'Vet. Tech./Data Entry', '../FileUploads/AnimalClinic/img/staff/mkoch.jpg', NULL),
(7, 'Pam Kellett', 'Vet. Tech.', '../FileUploads/AnimalClinic/img/staff/pkellett.jpg', NULL),
(8, 'Jamie Haney', 'Vet. Tech.', '../FileUploads/AnimalClinic/img/staff/jhaney.jpg', NULL),
(9, 'Lindsay Cooper', 'Vet. Tech.', '../FileUploads/AnimalClinic/img/staff/lcooper.jpg', NULL),
(10, 'Nikki Gilbert', 'Vet. Tech.', '../FileUploads/AnimalClinic/img/staff/ngilbert.jpg', NULL),
(11, 'Erin Galloway', 'Vet. Tech.', '../FileUploads/AnimalClinic/img/staff/egalloway.jpg', NULL),
(12, 'Stephanie Mittag', 'Vet. Tech.', '../FileUploads/AnimalClinic/img/staff/smittag.jpg', NULL),
(13, 'Andria Dennis', 'Surgical Tech.', '../FileUploads/AnimalClinic/img/staff/adennis.jpg', NULL),
(14, 'Mike McMillion', 'Transport Driver', '../FileUploads/AnimalClinic/img/staff/mmcmillion.jpg', NULL);
