
--
-- Indexes for dumped tables
--

--
-- Indexes for table `directors`
--
ALTER TABLE `directors`
  ADD PRIMARY KEY (`Director_ID`);

--
-- Indexes for table `medical_supplies`
--
ALTER TABLE `medical_supplies`
  ADD PRIMARY KEY (`Item_ID`);

--
-- Indexes for table `office_supplies`
--
ALTER TABLE `office_supplies`
  ADD PRIMARY KEY (`Item_ID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_ID`);

--
-- Indexes for table `transport_supplies`
--
ALTER TABLE `transport_supplies`
  ADD PRIMARY KEY (`Item_ID`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`Item_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `directors`
--
ALTER TABLE `directors`
  MODIFY `Director_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staff_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `Item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `medical_supplies`
--
ALTER TABLE `medical_supplies`
  ADD CONSTRAINT `medical_supplies_ibfk_1` FOREIGN KEY (`Item_ID`) REFERENCES `wishlist` (`Item_ID`);

--
-- Constraints for table `office_supplies`
--
ALTER TABLE `office_supplies`
  ADD CONSTRAINT `office_supplies_ibfk_1` FOREIGN KEY (`Item_ID`) REFERENCES `wishlist` (`Item_ID`);

--
-- Constraints for table `transport_supplies`
--
ALTER TABLE `transport_supplies`
  ADD CONSTRAINT `transport_supplies_ibfk_1` FOREIGN KEY (`Item_ID`) REFERENCES `wishlist` (`Item_ID`);
